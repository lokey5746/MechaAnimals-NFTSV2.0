import * as React from "react";
import PropTypes from "prop-types";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";

import rocket from "../img/Rocket2.png";

// ======Species ======//
import dragon from "../img/Dragon.png";
import ox from "../img/Ox.png";
import snake from "../img/Snake.png";
import rat from "../img/demo.png";
import sheep from "../img/Sheep.png";
import tiger from "../img/Tiger.png";
import monkey from "../img/Monkey.png";
import rabbit from "../img/Rabbit.png";
import dog from "../img/Dog.png";
import horse from "../img/Horse.png";
import rooster from "../img/Rooster.png";
import pig from "../img/Pig.png";

// =====Rat Data=====//
import rat1 from "../img/rat1.png";
import rat2 from "../img/rat2.png";
import rat3 from "../img/rat3.png";
import rat4 from "../img/rat4.png";
import rat5 from "../img/rat5.png";

// import rarityData from "../handler/rarityData";

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    "aria-controls": `simple-tabpanel-${index}`,
  };
}

function Rarity() {
  // const [items, setItems] = useState(rarityData);
  const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  return (
    <section className="relative">
      <div className="px-10 md:px-36 mt-5 py-5 w-full mx-auto">
        <h3 className="text-blue font-semibold text-2xl md:text-5xl text-center">
          Rarity
        </h3>

        <div>
          <Box sx={{ width: "100%" }}>
            <TabPanel
              value={value}
              index={0}
              className="tabpanel border border-blue rounded-lg md:max-w-4xl mx-auto my-10 py-5"
            >
              <div className="grid grid-cols-5 gap-5">
                <figure className="flex flex-col items-center">
                  <h3>RAT V1</h3>
                  <img className="" src={rat1} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center mt-24">
                  <h3>RAT V2</h3>
                  <img className="" src={rat2} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center">
                  <h3>GOLD</h3>
                  <img className="" src={rat3} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center mt-24">
                  <h3>DlAMOND</h3>
                  <img className="" src={rat4} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center">
                  <h3>RAlNBOW</h3>
                  <img src={rat5} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
              </div>
            </TabPanel>
            <TabPanel
              value={value}
              index={1}
              className="tabpanel border border-blue rounded-lg md:max-w-4xl mx-auto my-10 py-5"
            >
              <div className="grid grid-cols-5 gap-5">
                <figure className="flex flex-col items-center">
                  <h3>RAT V2</h3>
                  <img className="" src={rat1} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center mt-24">
                  <h3>RAT V2</h3>
                  <img className="" src={rat2} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center">
                  <h3>GOLD</h3>
                  <img className="" src={rat3} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center mt-24">
                  <h3>DlAMOND</h3>
                  <img className="" src={rat4} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center">
                  <h3>RAlNBOW</h3>
                  <img src={rat5} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
              </div>
            </TabPanel>
            <TabPanel
              value={value}
              index={2}
              className="tabpanel border border-blue rounded-lg md:max-w-4xl mx-auto my-10 py-5"
            >
              <div className="grid grid-cols-5 gap-5">
                <figure className="flex flex-col items-center">
                  <h3>RAT V3</h3>
                  <img className="" src={rat1} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center mt-24">
                  <h3>RAT V2</h3>
                  <img className="" src={rat2} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center">
                  <h3>GOLD</h3>
                  <img className="" src={rat3} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center mt-24">
                  <h3>DlAMOND</h3>
                  <img className="" src={rat4} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center">
                  <h3>RAlNBOW</h3>
                  <img src={rat5} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
              </div>
            </TabPanel>
            <TabPanel
              value={value}
              index={3}
              className="tabpanel border border-blue rounded-lg md:max-w-4xl mx-auto my-10 py-5"
            >
              <div className="grid grid-cols-5 gap-5">
                <figure className="flex flex-col items-center">
                  <h3>RAT V4</h3>
                  <img className="" src={rat1} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center mt-24">
                  <h3>RAT V2</h3>
                  <img className="" src={rat2} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center">
                  <h3>GOLD</h3>
                  <img className="" src={rat3} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center mt-24">
                  <h3>DlAMOND</h3>
                  <img className="" src={rat4} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center">
                  <h3>RAlNBOW</h3>
                  <img src={rat5} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
              </div>
            </TabPanel>
            <TabPanel
              value={value}
              index={4}
              className="tabpanel border border-blue rounded-lg md:max-w-4xl mx-auto my-10 py-5"
            >
              <div className="grid grid-cols-5 gap-5">
                <figure className="flex flex-col items-center">
                  <h3>RAT V5</h3>
                  <img className="" src={rat1} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center mt-24">
                  <h3>RAT V2</h3>
                  <img className="" src={rat2} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center">
                  <h3>GOLD</h3>
                  <img className="" src={rat3} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center mt-24">
                  <h3>DlAMOND</h3>
                  <img className="" src={rat4} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center">
                  <h3>RAlNBOW</h3>
                  <img src={rat5} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
              </div>
            </TabPanel>
            <TabPanel
              value={value}
              index={5}
              className="tabpanel border border-blue rounded-lg md:max-w-4xl mx-auto my-10 py-5"
            >
              <div className="grid grid-cols-5 gap-5">
                <figure className="flex flex-col items-center">
                  <h3>RAT V6</h3>
                  <img className="" src={rat1} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center mt-24">
                  <h3>RAT V2</h3>
                  <img className="" src={rat2} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center">
                  <h3>GOLD</h3>
                  <img className="" src={rat3} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center mt-24">
                  <h3>DlAMOND</h3>
                  <img className="" src={rat4} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center">
                  <h3>RAlNBOW</h3>
                  <img src={rat5} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
              </div>
            </TabPanel>
            <TabPanel
              value={value}
              index={6}
              className="tabpanel border border-blue rounded-lg md:max-w-4xl mx-auto my-10 py-5"
            >
              <div className="grid grid-cols-5 gap-5">
                <figure className="flex flex-col items-center">
                  <h3>RAT V7</h3>
                  <img className="" src={rat1} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center mt-24">
                  <h3>RAT V2</h3>
                  <img className="" src={rat2} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center">
                  <h3>GOLD</h3>
                  <img className="" src={rat3} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center mt-24">
                  <h3>DlAMOND</h3>
                  <img className="" src={rat4} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center">
                  <h3>RAlNBOW</h3>
                  <img src={rat5} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
              </div>
            </TabPanel>
            <TabPanel
              value={value}
              index={7}
              className="tabpanel border border-blue rounded-lg md:max-w-4xl mx-auto my-10 py-5"
            >
              <div className="grid grid-cols-5 gap-5">
                <figure className="flex flex-col items-center">
                  <h3>RAT V8</h3>
                  <img className="" src={rat1} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center mt-24">
                  <h3>RAT V2</h3>
                  <img className="" src={rat2} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center">
                  <h3>GOLD</h3>
                  <img className="" src={rat3} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center mt-24">
                  <h3>DlAMOND</h3>
                  <img className="" src={rat4} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center">
                  <h3>RAlNBOW</h3>
                  <img src={rat5} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
              </div>
            </TabPanel>
            <TabPanel
              value={value}
              index={8}
              className="tabpanel border border-blue rounded-lg md:max-w-4xl mx-auto my-10 py-5"
            >
              <div className="grid grid-cols-5 gap-5">
                <figure className="flex flex-col items-center">
                  <h3>RAT V9</h3>
                  <img className="" src={rat1} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center mt-24">
                  <h3>RAT V2</h3>
                  <img className="" src={rat2} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center">
                  <h3>GOLD</h3>
                  <img className="" src={rat3} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center mt-24">
                  <h3>DlAMOND</h3>
                  <img className="" src={rat4} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center">
                  <h3>RAlNBOW</h3>
                  <img src={rat5} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
              </div>
            </TabPanel>
            <TabPanel
              value={value}
              index={9}
              className="tabpanel border border-blue rounded-lg md:max-w-4xl mx-auto my-10 py-5"
            >
              <div className="grid grid-cols-5 gap-5">
                <figure className="flex flex-col items-center">
                  <h3>RAT V10</h3>
                  <img className="" src={rat1} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center mt-24">
                  <h3>RAT V2</h3>
                  <img className="" src={rat2} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center">
                  <h3>GOLD</h3>
                  <img className="" src={rat3} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center mt-24">
                  <h3>DlAMOND</h3>
                  <img className="" src={rat4} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center">
                  <h3>RAlNBOW</h3>
                  <img src={rat5} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
              </div>
            </TabPanel>
            <TabPanel
              value={value}
              index={10}
              className="tabpanel border border-blue rounded-lg md:max-w-4xl mx-auto my-10 py-5"
            >
              <div className="grid grid-cols-5 gap-5">
                <figure className="flex flex-col items-center">
                  <h3>RAT V11</h3>
                  <img className="" src={rat1} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center mt-24">
                  <h3>RAT V2</h3>
                  <img className="" src={rat2} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center">
                  <h3>GOLD</h3>
                  <img className="" src={rat3} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center mt-24">
                  <h3>DlAMOND</h3>
                  <img className="" src={rat4} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center">
                  <h3>RAlNBOW</h3>
                  <img src={rat5} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
              </div>
            </TabPanel>
            <TabPanel
              value={value}
              index={11}
              className="tabpanel border border-blue rounded-lg md:max-w-4xl mx-auto my-10 py-5"
            >
              <div className="grid grid-cols-5 gap-5">
                <figure className="flex flex-col items-center">
                  <h3>RAT V12</h3>
                  <img className="" src={rat1} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center mt-24">
                  <h3>RAT V2</h3>
                  <img className="" src={rat2} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center">
                  <h3>GOLD</h3>
                  <img className="" src={rat3} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center mt-24">
                  <h3>DlAMOND</h3>
                  <img className="" src={rat4} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
                <figure className="flex flex-col items-center">
                  <h3>RAlNBOW</h3>
                  <img src={rat5} alt="" />
                  <p className="text-blue text-base">12.05%</p>
                </figure>
              </div>
            </TabPanel>
            <div className="flex flex-col items-center pb-5 space-y-5">
              <h2 className="text-blue font-semibold text-2xl md:text-5xl text-center">
                Species
              </h2>
              <p className="text-base md:text-xl">
                Click on any Mechanimal to view their rarity.
              </p>
            </div>

            <Box>
              <Tabs
                value={value}
                onChange={handleChange}
                aria-label="basic tabs example"
                className="tab-container"
              >
                <Tab
                  className="tab"
                  label={
                    <div className="py-2">
                      <img className="h-10 md:h-20" src={dragon} />
                      <p className="text-white text-base">DRAGON</p>
                    </div>
                  }
                  {...a11yProps(0)}
                />
                <Tab
                  className="tab"
                  label={
                    <div className="py-2">
                      <img className="h-10 md:h-20" src={ox} />
                      <p className="text-white text-base">OX</p>
                    </div>
                  }
                  {...a11yProps(1)}
                />
                <Tab
                  className="tab"
                  label={
                    <div className="py-2">
                      <img className="h-10 md:h-20" src={snake} />
                      <p className="text-white text-base">SNAKE</p>
                    </div>
                  }
                  {...a11yProps(2)}
                />
                <Tab
                  className="tab"
                  label={
                    <div className="py-2">
                      <img className="h-10 md:h-20" src={rat} />
                      <p className="text-white text-base">RAT</p>
                    </div>
                  }
                  {...a11yProps(3)}
                />
                <Tab
                  className="tab"
                  label={
                    <div className="py-2">
                      <img className="h-10 md:h-20" src={sheep} />
                      <p className="text-white text-base">SHEEP</p>
                    </div>
                  }
                  {...a11yProps(4)}
                />
                <Tab
                  className="tab"
                  label={
                    <div className="py-2">
                      <img className="h-10 md:h-20" src={tiger} />
                      <p className="text-white text-base">TIGER</p>
                    </div>
                  }
                  {...a11yProps(5)}
                />
                <Tab
                  className="tab"
                  label={
                    <div className="py-2">
                      <img className="h-10 md:h-20" src={monkey} />
                      <p className="text-white text-base">MONKEY</p>
                    </div>
                  }
                  {...a11yProps(6)}
                />
                <Tab
                  className="tab"
                  label={
                    <div className="py-2 ">
                      <img className="h-10 md:h-20" src={rabbit} />
                      <p className="text-white text-base">RABBIT</p>
                    </div>
                  }
                  {...a11yProps(7)}
                />
                <Tab
                  className="tab"
                  label={
                    <div className="py-2">
                      <img className="h-10 md:h-20" src={dog} />
                      <p className="text-white text-base">DOG</p>
                    </div>
                  }
                  {...a11yProps(8)}
                />
                <Tab
                  className="tab"
                  label={
                    <div className="py-2">
                      <img className="h-10 md:h-20" src={horse} />
                      <p className="text-white text-base">HORSE</p>
                    </div>
                  }
                  {...a11yProps(9)}
                />
                <Tab
                  className="tab"
                  label={
                    <div className="py-2">
                      <img className="h-10 md:h-20" src={rooster} />
                      <p className="text-white text-base">ROOSTER</p>
                    </div>
                  }
                  {...a11yProps(10)}
                />
                <Tabs
                  className="tab"
                  label={
                    <div className="py-2">
                      <img className="h-10 md:h-20" src={pig} />
                      <p className="text-white text-base">PIG</p>
                    </div>
                  }
                  {...a11yProps(11)}
                />
              </Tabs>
            </Box>
          </Box>
        </div>
      </div>
      <figure className="h-20 hidden md:block">
        <img
          className="absolute -top-10 right-0 opacity-60"
          src={rocket}
          alt="Earth Image"
        />
      </figure>
    </section>
  );
}

export default Rarity;
