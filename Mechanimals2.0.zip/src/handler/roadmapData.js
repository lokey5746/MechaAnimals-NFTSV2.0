import Roadmap1 from "../img/Roadmap-1.png";
import Roadmap2 from "../img/Roadmap-2.png";
import Roadmap3 from "../img/Roadmap-3.png";
import Roadmap4 from "../img/Roadmap-4.png";

export default [
  {
    id: 1,
    image: Roadmap3,
    text: "Launching Website ",
  },
  {
    id: 2,
    image: Roadmap3,
    text: "Minting of NFT",
  },
  {
    id: 3,
    image: Roadmap3,
    text: "Launching of market place",
  },
  {
    id: 4,
    image: Roadmap3,
    text: "Limited edition airdrop for MechAnimal holders",
  },
  {
    id: 5,
    image: Roadmap3,
    text: "Minting of Series 2 NFT",
  },
  {
    id: 6,
    image: Roadmap4,
    text: "Presentation of merchandise ",
  },
  {
    id: 7,
    image: Roadmap4,
    text: "First collaboration with another faboulus project",
  },
];
