import team1 from "../img/team1.png";
import team2 from "../img/team2.png";
import team3 from "../img/team3.png";
import team4 from "../img/team4.png";
import team5 from "../img/team1.png";
import team6 from "../img/team2.png";
import team7 from "../img/team3.png";
import team8 from "../img/team4.png";

export default [
  {
    id: 1,
    image: team1,
    name: "the_machine",
    role: "CRYPTO ADVlSOR",
  },
  {
    id: 2,
    image: team2,
    name: "Cryptoben",
    role: "CEO",
  },
  {
    id: 3,
    image: team3,
    name: "Mr_sudeep",
    role: "BLOCKCHAlN PROGRAMMER",
  },
  {
    id: 4,
    image: team4,
    name: "MechaGod",
    role: "ARTlST",
  },
  {
    id: 5,
    image: team5,
    name: "Darian1",
    role: "CRYPTO MARKETING EXPERT",
  },
  {
    id: 6,
    image: team6,
    name: "MUSF1K",
    role: "COMMUNlTY MANAGER",
  },
  {
    id: 7,
    image: team7,
    name: "Daria1496",
    role: "ADVlSOR",
  },
  {
    id: 8,
    image: team8,
    name: "Zay Nakarmy",
    role: "Ul DESlGNER",
  },
];
