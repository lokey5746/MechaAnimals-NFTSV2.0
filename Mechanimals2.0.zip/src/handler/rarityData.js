import image1 from "../img/Dog.png";
import image2 from "../img/Dragon.png";
import image3 from "../img/Horse.png";
import image4 from "../img/Monkey.png";
import image5 from "../img/Ox.png";
import image6 from "../img/Pig.png";
import image7 from "../img/Rabbit.png";
import image8 from "../img/Rat.png";
import image9 from "../img/Rooster.png";
import image10 from "../img/Sheep.png";
import image11 from "../img/Snake.png";
import image12 from "../img/Tiger.png";

export default [
  {
    id: 1,
    image: image2,
    name: "Dragon",
    rate: "0.21%",
  },
  {
    id: 2,
    image: image5,
    name: "Ox",
    rate: "1.50%",
  },
  {
    id: 3,
    image: image11,
    name: "Snake",
    rate: "2.74%",
  },
  {
    id: 4,
    image: image4,
    name: "Monkey",
    rate: "3.93%",
  },
  {
    id: 5,
    image: image7,
    name: "Rabbit",
    rate: "5.80%",
  },
  {
    id: 6,
    image: image6,
    name: "Pig",
    rate: "7.49%",
  },
  {
    id: 7,
    image: image3,
    name: "Horse",
    rate: "9.77%",
  },
  {
    id: 8,
    image: image1,
    name: "Dog",
    rate: "10.97%",
  },

  {
    id: 9,
    image: image8,
    name: "Rat",
    rate: "12.05%",
  },
  {
    id: 10,
    image: image10,
    name: "Sheep",
    rate: "13.52%",
  },
  {
    id: 11,
    image: image12,
    name: "Tiger",
    rate: "15.04%",
  },
  {
    id: 12,
    image: image9,
    name: "Rooster",
    rate: "16.98%",
  },
];
