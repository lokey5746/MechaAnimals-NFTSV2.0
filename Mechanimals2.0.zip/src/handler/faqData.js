export default [
  {
    id: 1,
    question: "When is the MechAnimal sale?",
    answer: "The sale will begin on 03/01/22 at 1700 UTC",
  },
  {
    id: 2,
    question: "How many MechAninamls will be sold?",
    answer:
      "There are 10,000 unique MechAnimals NFTs. 9,900 MechAnimals will be sold in a single drop. 100 MechAnimals will be withheld from the sale for giveaways, promotions, and the creative team.",
  },
  {
    id: 3,
    question: "How much will the MechAnimals NFTs cost?",
    answer: "Starting from 32 ADA",
  },
  {
    id: 4,
    question: "What wallets can I use?",
    answer:
      "DO NOT SEND ADA FROM AN EXCHANGE. ADA must be sent from your own Cardano wallet. Such as Nami, Daedalus or Yuroi. Be careful of fake wallets!",
  },
  {
    id: 5,
    question: "Can I buy more than 1 MechAnimal at the same time?",
    answer: "Yes, costumer will be able to mint up to 5 per transaction.",
  },
  {
    id: 6,
    question:
      "How long does it take to receive my MechAnimal after I send my ADA?",
    answer:
      "This will depend on a number of considerations such as network volume and popularity of the project. Please allow for up to a full day to receive a MechAnimal or a refund.",
  },

  {
    id: 7,
    question: "I sent the wrong amount of ADA, what happens?",
    answer: "You'll receive a refund minus the transaction fees.",
  },
  {
    id: 8,
    question:
      "I ignored your instructions and sent ADA from an exchange. Please help!",
    answer:
      "We're sorry, but there's nothing we can do to help. Your MechAnimal NFT was sent to the exchange. Please contact your exchange.",
  },
  {
    id: 9,
    question: "How can I reach out for assistance?",
    answer:
      "Our Discord Server has a ticket system for assistance. Please submit a ticket providing the details of your problem or concern and we'll try to assist. Do not ask for or accept assistance from anyone via any other channels or means of communication. They are almost all certainly scams to steal your ADA and NFTs.",
  },
  {
    id: 10,
    question: "How can I use my MechAnimal NFT?",
    answer:
      "MechAnimals is a collection of digital artworks created as Non-Fungible Tokens (NFTs) on the Cardano network. When you purchase a MechAnimal NFT, you own that specific NFT on the Cardano blockchain.",
  },
];
