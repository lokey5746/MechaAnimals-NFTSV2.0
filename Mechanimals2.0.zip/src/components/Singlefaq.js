import React from "react";

function Singlefaq() {
  return <div></div>;
}

export default Singlefaq;
