import React from "react";

function SIngleTeam() {
  return <div></div>;
}

export default SIngleTeam;
