import React from "react";

function Event() {
  return (
    <footer>
      <div></div>
    </footer>
  );
}

export default Event;
